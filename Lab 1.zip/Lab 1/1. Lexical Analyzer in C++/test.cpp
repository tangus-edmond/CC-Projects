#include <iostream>

using namespace std;

int main()
{
    
    int x = 1, y = 2, z = 0;
    z = x + y;

    cout << "Sum is: " << z; 
    
    return 0;
}